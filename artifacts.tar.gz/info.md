FredMDQD is written by Enrico Wegner. FredMDQD and Enrico Wegner are not affiliated with the Federal Reserve Bank of St. Louis.

FRED MD and FRED QD data is officially compiled by Michael W. McCracken at the Federal Reserve Bank of St Louis. Information regarding the compilation, recent changes, and how to cite the data can be found on the offical website: 

https://research.stlouisfed.org/econ/mccracken/fred-databases/

!!!
FRED MD and FRED QD data must always be cited
!!!
