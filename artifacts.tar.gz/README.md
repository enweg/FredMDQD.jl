# Artifacts for FredMDQD.jl

Artifact files contain additional information used for the main library.

## Notes

- Appendix for Fred MD and Fred QD were downloaded from https://research.stlouisfed.org/econ/mccracken/fred-databases/ at 15:00 13/04/2024

## How to create artifacts.tar.gz

1. `rm artifacts.tar.gz`
2. `tar -czvf artifacts.tar.gz *`


